package deal.command;

import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import deal.bean.GoodsDBBean;
import deal.bean.GoodsDataBean;

public class UpdateGoodsAction implements CommandAction {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response) throws Throwable {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		
		String fileName = "";
		String realFolder = "";
		String saveFolder = "/upload";
		String encType = "utf-8";
		int maxSize = 5 * 1024 * 1024;

		MultipartRequest imageUp = null;

		ServletContext context = request.getSession().getServletContext();
		realFolder = context.getRealPath(saveFolder);

		try {
			imageUp = new MultipartRequest(request, realFolder, maxSize, encType, new DefaultFileRenamePolicy());
			Enumeration<?> files = imageUp.getFileNames();

			while (files.hasMoreElements()) {
				String name = (String) files.nextElement();
				fileName = imageUp.getFilesystemName(name);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		GoodsDataBean goods = new GoodsDataBean();
		goods.setGoodsName(imageUp.getParameter("goodsName"));
		goods.setImageFile(fileName);
		goods.setExplanation(imageUp.getParameter("explanation"));
		goods.setAuctionPrice(Integer.parseInt(imageUp.getParameter("auctionPrice")));
		goods.setGoodsDate(imageUp.getParameter("goodsDate"));

		GoodsDBBean db = GoodsDBBean.getInstance();
		int result = db.insertGoods(goods);

		if (result == 0) {
			System.out.println("����");
		} else {
			System.out.println("���");
		}
		
		return	"/adminIndex.jsp";
	}

}
