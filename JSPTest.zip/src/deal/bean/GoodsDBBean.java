package deal.bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class GoodsDBBean {
	private static GoodsDBBean	instance	=	new	GoodsDBBean();
	
	private	GoodsDBBean() {}
	
	public static GoodsDBBean getInstance() {
		return	instance;
	}
	
	// DB Connection
	public Connection getConnection() throws Exception {
		Context	initCtx	=	new	InitialContext();
		Context	envCtx	=	(Context)initCtx.lookup("java:comp/env");
		DataSource ds	=	(DataSource)envCtx.lookup("jdbc/test");
		
		return	ds.getConnection();
	}
	
	// ��ǰ insert
	public int insertGoods(GoodsDataBean goods) {
		Connection			conn	=	null;
		PreparedStatement	pstmt	=	null;
		int 				result	=	0;
		
		try {
			conn	=	getConnection();
			pstmt	=	conn.prepareStatement("insert into goods (goodsName, imageFile, explanation, auctionPrice, goodsDate) "
					+ "values(?, ?, ?, ?, ?);");
			pstmt.setString(1, goods.getGoodsName());
			pstmt.setString(2, goods.getImageFile());
			pstmt.setString(3, goods.getExplanation());
			pstmt.setInt(4, goods.getAuctionPrice());
			pstmt.setString(5, goods.getGoodsDate());
			result	=	pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if(pstmt != null) try {pstmt.close();} catch (SQLException e) {};
			if(conn != null) try {conn.close();} catch(SQLException e) {};
		}
		return	result;
	}
	
	public ArrayList<GoodsDataBean> GoodsView() throws Exception {
		Connection			conn	=	null;
		PreparedStatement	pstmt	=	null;
		ResultSet			rs		=	null;
		
		conn	=	getConnection();
		pstmt	=	conn.prepareStatement("select * from goods");
		rs		=	pstmt.executeQuery();
		
		ArrayList<GoodsDataBean>	result	=	new	ArrayList<GoodsDataBean>();
		
		while(rs.next()) {
			GoodsDataBean	data	=	new	GoodsDataBean();
			data.setGoodsId(rs.getInt("goodsId"));
			data.setGoodsName(rs.getString("goodsName"));
			data.setImageFile(rs.getString("imageFile"));
			data.setExplanation(rs.getString("explanation"));
			data.setAuctionPrice(rs.getInt("auctionPrice"));
			data.setGoodsDate(rs.getString("goodsDate"));
			result.add(data);
		}
		return	result;
	}
}
